<?php
require_once("../../../../config/database.php");

$id = $_GET['id'];

$sql = "DELETE FROM employees WHERE id='$id'";
$query = $db->prepare($sql);
$query->execute();

session_start();
$_SESSION['flashMessage'] = ['message' => 'Darbinieks dzēsts!', 'type' => 'danger'];

header("location: list.php");
?>