<?php
require_once("../../../../config/database.php");

$id = $_GET['id'];

$sql = "DELETE FROM positions WHERE id='$id'";
$query = $db->prepare($sql);
$query->execute();

session_start();
$_SESSION['flashMessage'] = ['message' => 'Amats dzēsts!', 'type' => 'danger'];

header("location: list.php");
?>