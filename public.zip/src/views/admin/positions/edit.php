<?php
require_once("../../../../config/database.php");

$formErrors["name"] = "";

if (isset($_POST['submit'])) {
    $name = trim($_POST['name']);
    $id = $_POST['id'];

    if (empty($name)) {
        $formErrors['name'] = "Lūdzu ievadiet amatu.";
    }

    if (empty(array_filter($formErrors))) {
        $query = $db->prepare("UPDATE positions SET name = '$name' WHERE id = '$id'");
        $query->execute();

        session_start();
        $_SESSION['flashMessage'] = ['message' => 'Amats labots!', 'type' => 'success'];

        header("location: list.php");
        exit;
    }
}

if (!isset($_GET['id'])) {
    header("location: list.php");
}

$id = $_GET['id'];
$query = $db->prepare("SELECT * FROM positions WHERE id = $id");
$query->execute();
if ($query->rowCount() == 0) {
    header("location: list.php");
} else {
    $position = $query->fetch();
}
?>

<?php require_once("../../layout/admin-sidebar.php"); ?>

<div class="card">
    <div class="card-header">
        <h2 class="m-0">Rediģēt amatu</h2>
    </div>
    <form method="post">
        <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
        <div class="card-body">
            <div class="form-group mb-3">
                <label for="name">Amats <span class="text-danger">*</span></label>
                <input type="text" class="form-control <?php echo (! empty($formErrors['name'])) ? 'is-invalid' : ''; ?>" name="name" id="name" placeholder="Ievadi vārdu" value="<?php echo $position['name'] ?>">
                <span class="invalid-feedback"><?php echo $formErrors['name'] ?></span>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" name="submit" class="btn btn-success">Saglabāt</button>
            <a href="list.php" type="button" class="btn btn-secondary">Atcelt</a>
        </div>
    </form>
</div>

<?php require_once("../../layout/admin-footer.php"); ?>